import Image from "next/image";
import React from "react";

export default function SmallCard({ location, img, distance }) {
  return (
    <div className="flex space-x-4 items-center mt-5 m-2 cursor-pointer hover:bg-gray-100 hover:scale-105 rounded-xl transition transform duration-105 ease-out">
      <div className="relative h-16 w-16">
        <Image src={img} layout="fill" className="rounded-lg"></Image>
      </div>
      <div>
        <h2>{location}</h2>
        <h3 className="text-gray-500">{distance}</h3>
      </div>
    </div>
  );
}
