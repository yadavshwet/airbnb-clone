import Image from "next/image";
import {
  MagnifyingGlassIcon,
  GlobeAltIcon,
  UserCircleIcon,
  UserIcon,
  Bars3Icon,
  UsersIcon,
  HeartIcon
} from "@heroicons/react/24/solid";
import { useState } from "react";
import "react-date-range/dist/styles.css"; // main css file
import "react-date-range/dist/theme/default.css"; // theme css file
import { DateRangePicker } from "react-date-range";
import Link from "next/link";
import { useRouter } from "next/router";

function Header({placeholder}) {
  const [searchInput, setSearchInput] = useState("");
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [noOfGuests, setNoOfGuests] = useState(1);
  const router = useRouter();


  const selectionRange = {
    startDate,
    endDate,
    key: "selection",
  };

  const handleChange = (ranges) => {
    setStartDate(ranges.selection.startDate);
    setEndDate(ranges.selection.endDate);
  };

  const resetInput = () => {
    setSearchInput("");
  };

  const handleSearch = () => {

    console.log(
      {location: searchInput,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        noOfGuests: noOfGuests}
    )
    router.push({
      pathname: '/search',
      query: {
        location: searchInput,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        noOfGuests: noOfGuests
      }
    })


  }

  return (
    <header className="grid sticky top-0 z-50 grid-cols-3 p-3 shadow-md md:px-10 bg-white">
      <div className="flex items-center cursor-pointer h-10 relative my-auto" onClick={() => router.push('/')}>
        <Image
          src="https://links.papareact.com/qd3"
          fill
          objectFit="contain"
          objectPosition="left"
          alt="no-image"
        />
      </div>
      {/* Search icon */}
      <div className="flex items-center md:border-2 md:shadow-sm rounded-full p-3">
        <input
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          type="text"
          placeholder={placeholder || "Start your search"}
          className="flex-grow pl-5 bg-transparent outline-none"
        />

        <MagnifyingGlassIcon className="hidden h-8 bg-red-400 fill-white rounded-full p-2 cursor-pointer md:inline-flex ml-1" />
      </div>

      {/* right part of Header */}

      <div className="flex items-center justify-end text-gray-500 space-x-4 cursor-pointer">
        <p className="hidden md:inline">Become a host</p>
        <GlobeAltIcon className="h-6" />

        <div className="flex space-x-2 items-center border-2 rounded-full p-2 ">
          <Bars3Icon className="h-6" />
          <UserCircleIcon className="h-6" />
        </div>
      </div>

      {searchInput && (
        <div className="flex flex-col col-span-3 mx-auto my-5">
          <DateRangePicker
            ranges={[selectionRange]}
            minDate={new Date()}
            rangeColors={["#FD5B61"]}
            onChange={handleChange}
          />
          <div className="flex border-b items-center mb-5">
            <h2 className="text-2xl flex-grow font-semibold">
              Number of Guests
            </h2>
            <UsersIcon className="h-5 pr-2" />
            <input
              value={noOfGuests}
              min={1}
              onChange={(e) => setNoOfGuests(e.target.value)}
              type="number"
              className="w-12 pl-2 text-lg outline-none text-red-400"
            />
          </div>
          <div className="flex justify-between p-1">
            <button className="flex-grow text-grey-500" onClick={resetInput}>
              Cancel
            </button>
            <button className="flex-grow text-red-400" onClick={handleSearch}>
            Search
            </button>
          </div>
        </div>
      )}
    </header>
  );
}

export default Header;
