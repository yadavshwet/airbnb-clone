import Image from "next/image";
import LargeCard from "./LargeCard";
import MediumCard from "./MeduimCard";
import SmallCard from "./SmallCard";

function Main({ exploreData }) {
  return (
    <main className="max-w-7xl md:mx-auto  lg:mx-auto  xl:mx-auto  px-8 sm:px-16">
      <section className="pt-6">
        <h2 className="font-semibold pb-5 text-4xl">Explore Nearby</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
          {exploreData?.nearby?.map(({ img, location, distance } , index) => {
            return (
              <SmallCard
                key={index}
                img={img}
                location={location}
                distance={distance}
              />
            );
          })}
        </div>
      </section>

      <section>
        <h2 className="font-semibold text-4xl py-6">Live Anywhere</h2>
        <div className="flex overflow-x-scroll scrollbar-hide space-x-5">
        {exploreData?.anywhere?.map((data, index) => (
          <MediumCard key={index} img={data.img} title={data.title} />
        ))}
        </div>
      
      </section>

        <LargeCard img={'https://links.papareact.com/4cj'} 
        title="The Greatest Outdoors"
        description={'WishList curated by Airbnb'}
        btnText={'Get Inspired'}/>
    </main>
  );
}

export default Main;
